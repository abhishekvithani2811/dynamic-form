let obj = {
  name:Date.now(),
  age:23
}


for(let object in obj){
  console.log(`${object}- ${obj[object]}`);
  
}