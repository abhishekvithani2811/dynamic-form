import './App.css'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './modual/home';
import Header from './componant/header';
import FormBuilder from './modual/FormBuilder';
import FormBuilderComponent from './modual/FormBuilderComponent';

function App() {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<FormBuilder />}></Route>
          <Route path="/formBuilderComponent" element={<FormBuilderComponent />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
