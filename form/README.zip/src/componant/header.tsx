import React from 'react'
import DescriptionIcon from '@mui/icons-material/Description';
import '../App.css'
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import ColorLensIcon from '@mui/icons-material/ColorLens';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
function Header() {
    return (
        <div>
            <div className='  bg-slate-50'>
                <div className='flex justify-between pt-3'>
                    <div className=' flex justify-start pl-4 '>
                        <div className=' file_icon'>
                            <DescriptionIcon />
                        </div>
                        <div className='ml-3 font-serif mt-3 text-xl '>
                            Untitled form
                        </div>
                        <div className='mt-3 mx-4 text-slate-500'>
                            <FolderOpenIcon />
                        </div>
                        <div className='mt-3 text-slate-500'>
                            <StarBorderIcon />
                        </div>
                        <div className='mt-4 ml-8  text-sm text-slate-500'>All change in drive</div>
                    </div>
                    <div className='flex justify-end mb-7 px-16'>
                        <div className='px-5 pt-2 text-slate-500'>
                            <ColorLensIcon />
                        </div>
                        <div className='px-3  pt-2 text-slate-500'>
                            <RemoveRedEyeIcon />
                        </div>
                        <div className='px-3  pt-2 text-slate-500'>
                            <ArrowBackIcon />
                        </div>
                        <div className='px-3 pr-4  pt-2 text-slate-500 '>
                            <ArrowForwardIcon />
                        </div>
                        <div className='Send'>
                            <button type='submit' className=" w-24 text-slate-50 font-bold py-2 px-4 rounded ">
                                Send
                            </button>
                        </div>
                    </div>
                </div>
                <div className='flex justify-center'>
                    <div className=' font-medium font-serif text-green-900 question  '>Question</div>
                    <div className='mx-7 font-medium font-serif'>Response</div>
                    <div className=' font-medium font-serif'>Setting</div>
                </div>
            </div>
        </div>
    )
}

export default Header
