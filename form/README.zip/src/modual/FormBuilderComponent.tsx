import React, { useEffect, useState } from 'react'
import axios from 'axios';

function FormBuilderComponent() {
  const [formComponents, setFormComponents] = useState<any[]>([]);

  interface FormComponent {
    question: string;
    inputType: string;
  }
  useEffect(() => {
    axios.get<FormComponent[]>('http://localhost:5000/formData')
      .then(response => {
        console.log(response.data)
        setFormComponents(response.data);
      })
      .catch(error => {
        console.error('Error fetching form data:', error);
      });
  }, []);
  return (
    <div>
      {formComponents.map((data) => (
        <>
          {data.map((data1: any) => {
            console.log(data1)
            return (
              <>
              {data1.question}
                <h1>  {data1.inputType === 'text' && <input type="text" />}</h1>
                <h1>  {data1.inputType === 'number' && <input type="number" />}</h1>
                <h1>  {data1.inputType === 'email' && <input type="email" />}</h1>
                <h1>  {data1.inputType === 'longtext' && <textarea rows={4} cols={50}></textarea>}</h1>
              </>
            )
          })}
        </>
      ))}
    </div >
  )
}

export default FormBuilderComponent
