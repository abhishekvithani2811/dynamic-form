import React, { useState } from 'react';
import axios from 'axios';

interface Question {
  id: number;
  text: string;
  type: string;
}

const GoogleForm = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const addQuestion = () => {
    const newQuestion: Question = {
      id: questions.length + 1,
      text: '',
      type: 'text',
    };
    setQuestions([...questions, newQuestion]);
  };

  const handleTextChange = (id: number, value: string) => {
    const updatedQuestions = questions.map(question =>
      question.id === id ? { ...question, text: value } : question
    );
    setQuestions(updatedQuestions);
  };

  const handleTypeChange = (id: number, value: string) => {
    const updatedQuestions = questions.map(question =>
      question.id === id ? { ...question, type: value } : question
    );
    setQuestions(updatedQuestions);
  };

  const submitForm = async () => {
    try {
      console.log(questions);
      const response = await axios.post('http://localhost:5000/formData', questions);
      console.log(response);
      alert('Form data submitted successfully!');
      setQuestions([]); // Clear questions after successful submission
    } catch (error) {
      console.error('Error submitting form data:', error);
      alert('Form data submission failed.');
    }
  };


  return (
    <div>
      <h1>Create Your Form</h1>
      <button onClick={addQuestion}>Add Question</button>
      <form>
        {questions.map(question => (
          <div key={question.id}>
            <input
              type="text"
              placeholder="Enter your question"
              value={question.text}
              onChange={e => handleTextChange(question.id, e.target.value)}
            />
            <select
              value={question.type}
              onChange={e => handleTypeChange(question.id, e.target.value)}
            >
              <option value="text">Text</option>
              <option value="number">Number</option>
              <option value="email">Email</option>
              <option value="checkbox">Checkbox</option>
              <option value="radio">Radio</option>
            </select>
            <input type={question.type} placeholder={`Enter your ${question.type}`} />
          </div>
        ))}
      </form>
      <button onClick={submitForm}>Submit</button>
      {/* {
        questions.map((field) => {
          return (

            field.question === "radio" && (
              <div className="my-4 flex flex-col space-y-2">
                {field.list.map((item: string) => (
                  <label
                    className="px-5 shadow-sm h-10 rounded-md  w-full flex items-center"
                    key={item}
                  >
                    <input type="radio" value={item} name={field.name} />
                    <span className="ml-2">{item}</span>
                  </label>
                ))}

                <div className="flex space-between">
                  <input
                    type="text"
                    onChange={(e) => setradioField(e.target.value)}
                    value={radiofield}
                    placeholder="Add an Option"
                    className="flex-auto"
                  />
                  <button
                    className="bg-indigo-700 block hover:bg-indigo-900 text-white px-4"
                    onClick={() => addRadioOption(field.name, radiofield)}
                  >
                    Add
                  </button>
                </div>
              </div>
            )

          )
        })
      } */}
    </div>
  );
};

export default GoogleForm;