import '../setting.css'
const Setting = () => {
    return (
        <div >
            <>
                
                <div className="message-box">
                    <h1 className='flex justify-center mt-10 text-7xl font-serif text-white under'>Under Construction ⌛</h1>
                   
                </div>
            </>
        </div>
    )
}

export default Setting
