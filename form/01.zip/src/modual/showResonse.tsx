import { useEffect, useState } from 'react';
import axios from 'axios';

function ShowResponse() {
    const [formComponents, setFormComponents] = useState<any[]>([]);
    const [FormQuestion, setFormQuestion] = useState<any[]>([]);


    useEffect(() => {
        axios.get('http://localhost:5000/Formresponse')
            .then(response => {
                // console.log(response.data)
                setFormComponents(response.data);
            })
            .catch(error => {
                console.error('Error fetching form data:', error);
            });
        // 
        axios.get('http://localhost:5000/formData',{
        
        })
            .then(response => {
                console.log(response.data)
                setFormQuestion(response.data);
            })
            .catch(error => {
                console.error('Error fetching form data:', error);
            });
    }, []);




    return (
        <div className="flex items-center justify-center min-h-screen " >
            <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
                <h1 className="text-2xl font-semibold text-center  mb-6" style={{ color: "#1F6A8A" }}>
                    Dynamic Form
                </h1>
                {formComponents.map((item) => {
                    return (
                        <div key={item.id}>
                            {Object.keys(item).map((key) => (
                                <div key={key} className="mb-2">
                                    <h3 className="text-lg font-medium text-[#000000]">{key}</h3>
                                    {Array.isArray(item[key]) ? (
                                        <ul className="list-disc pl-6">
                                            {item[key].map((value, idx) => (
                                                <li key={idx}>{value}</li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <p className="mt-1">{item[key]}</p>
                                    )}
                                </div>
                            ))}
                        </div>
                    )
                })}

                <div className="text-center">
                    <button className=" submitdata text-lg font px-4 py-2 rounded-md " >
                        submit
                    </button>

                </div>
            </div>

        </div>
    );
}

export default ShowResponse;
