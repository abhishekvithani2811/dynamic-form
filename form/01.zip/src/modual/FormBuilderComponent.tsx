import React, { useEffect, useState } from 'react';
import axios from 'axios';

function FormBuilderComponent() {
  const [formComponents, setFormComponents] = useState<any[]>([]);
  const [formResponse, setFormResponse] = useState<any>({});

  interface FormComponent {
    question: string;
    inputType: string;
  }

  useEffect(() => {
    axios.get<FormComponent[]>('http://localhost:5000/formData')
      .then(response => {
        console.log("response--", response.data)
        setFormComponents(response.data);
      })
      .catch(error => {
        console.error('Error fetching form data:', error);
      });
  }, []);

  const handleInputChange = (index1: number, index: number, value: any) => {
    console.log(value, "--value", index, "--index", index1, "--index1");
    const updateFormResponse = { ...formResponse };
    console.log(updateFormResponse);
    updateFormResponse[`question_${index1}_${index}`] = value;
    setFormResponse(updateFormResponse);
  };
  const handelFormSubmit = async () => {
    try {
      const response = await axios.post(
        "http://localhost:5000/Formresponse",
        formResponse
      );
      console.log("Form data submitted success ", response.data);
    } catch (error) {
      console.error("Error submitting form data:", error);
    }
  };
  const handleRadioChange = (index1: number, index: number, option: string) => {

    handleInputChange(index1, index, option);
  };
  const handleChackboxChange = (index1: number, selectedOption: any) => {
    // console.log(index1, "-----index1")
    const updatedOptions = formResponse[`question_${index1}_0`] || []; // Existing selected options or empty array
    const updatedOptionsSet = new Set(updatedOptions);

    if (updatedOptionsSet.has(selectedOption)) {
      updatedOptionsSet.delete(selectedOption);
    } else {
      updatedOptionsSet.add(selectedOption);
    }
    handleInputChange(index1, 0, Array.from(updatedOptionsSet));
  };
  return (
    <div className="flex items-center justify-center min-h-screen " >
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h1 className="text-2xl font-semibold text-center  mb-6" style={{ color: "#1F6A8A" }}>
          Dynamic Form
        </h1>
        {formComponents.map((data, dataIndex) => {
          return (
            <div key={dataIndex} className="mb-4">
              {data.questions.map((data1: any, data1Index: number) => {
                console.log(data.questions)
                return (
                  <div key={data1Index}>
                    <label className="block font-medium text-gray-700 mb-2">
                      <span className=' text-xl'> Q</span> {data1Index + 1}.<span className=' text-lg font-serif'> {data1.question}</span>
                    </label>
                    {data1.type === 'text' && (
                      <input
                        type="text"
                        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-500"
                        onChange={(e) =>
                          handleInputChange(dataIndex, data1Index, e.target.value)
                        }
                      />
                    )}
                    {(data1.type === 'checkbox') && (
                      <div className="space-y-2">
                        {data1.options.map((data2: any, data2Index: number) => (
                          <label
                            key={data2Index}
                            className="flex items-center space-x-2"
                          >
                            <input
                              type={data1.type}
                              className="form-checkbox h-5 w-5"
                              name={`question_${dataIndex}`}
                              onChange={() =>
                                handleChackboxChange(data1Index, data2)
                              }
                            />
                            <span>{data2.text}</span>
                          </label>
                        ))}
                      </div>
                    )}
                    {(data1.type === 'radio') && (
                      <div className="space-y-2">
                        {data1.options.map((data2: any, data2Index: number) => (
                          <label
                            key={data2Index}
                            className="flex items-center space-x-2"
                          >
                            <input
                              type={data1.type}
                              name="a"
                              className="form-checkbox h-5 w-5"
                              onChange={() =>
                                handleRadioChange(dataIndex, data1Index, data2)
                              }
                            />
                            <span>{data2.text}</span>
                          </label>
                        ))}
                      </div>
                    )}
                    {data1.type === 'textarea' && (
                      <textarea
                        rows={4}
                        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-500"
                        onChange={(e) =>
                          handleInputChange(dataIndex, data1Index, e.target.value)
                        }
                      ></textarea>
                    )}
                    {data1.type === 'email' && (
                      <input
                        type="email"
                        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-500"
                        onChange={(e) =>
                          handleInputChange(dataIndex, data1Index, e.target.value)
                        }
                      />
                    )}
                    {data1.type === 'number' && (
                      <input
                        type="number"
                        className="w-full px-3 py-2 border rounded-md focus:outline-none focus:border-blue-500"
                        onChange={(e) =>
                          handleInputChange(dataIndex, data1Index, e.target.value)
                        }
                      />
                    )}
                  </div>
                )
              })}

            </div>
          )
        })}
        <div className="text-center">
          <button className=" submitdata text-lg font px-4 py-2 rounded-md " onClick={handelFormSubmit}>
            submit
          </button>

        </div>
      </div>

    </div>
  );
}

export default FormBuilderComponent;
